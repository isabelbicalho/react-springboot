package io.swagger.api;

import io.swagger.model.NovaPessoaJuridica;
import io.swagger.model.PessoaJuridica;

import java.util.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PessoajuridicaApiControllerIntegrationTest {

    @Autowired
    private PessoajuridicaApi api;

    @Test
    public void pessoajuridicaGetTest() throws Exception {
        ResponseEntity<List<PessoaJuridica>> responseEntity = api.pessoajuridicaGet();
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

    @Test
    public void pessoajuridicaIdDeleteTest() throws Exception {
        Integer id = 56;
        ResponseEntity<Void> responseEntity = api.pessoajuridicaIdDelete(id);
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

    @Test
    public void pessoajuridicaIdGetTest() throws Exception {
        Integer id = 56;
        ResponseEntity<List<PessoaJuridica>> responseEntity = api.pessoajuridicaIdGet(id);
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

    @Test
    public void pessoajuridicaIdPutTest() throws Exception {
        NovaPessoaJuridica body = new NovaPessoaJuridica();
        Integer id = 56;
        ResponseEntity<PessoaJuridica> responseEntity = api.pessoajuridicaIdPut(body, id);
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

    @Test
    public void pessoajuridicaPostTest() throws Exception {
        PessoaJuridica body = new PessoaJuridica();
        ResponseEntity<NovaPessoaJuridica> responseEntity = api.pessoajuridicaPost(body);
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

}
