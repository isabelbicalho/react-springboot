package io.swagger.api;

import io.swagger.model.NovaPessoaFisica;
import io.swagger.model.PessoaFisica;

import java.util.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PessoafisicaApiControllerIntegrationTest {

    @Autowired
    private PessoafisicaApi api;

    @Test
    public void pessoafisicaGetTest() throws Exception {
        ResponseEntity<List<PessoaFisica>> responseEntity = api.pessoafisicaGet();
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

    @Test
    public void pessoafisicaIdDeleteTest() throws Exception {
        Integer id = 56;
        ResponseEntity<Void> responseEntity = api.pessoafisicaIdDelete(id);
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

    @Test
    public void pessoafisicaIdGetTest() throws Exception {
        Integer id = 56;
        ResponseEntity<List<PessoaFisica>> responseEntity = api.pessoafisicaIdGet(id);
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

    @Test
    public void pessoafisicaIdPutTest() throws Exception {
        NovaPessoaFisica body = new NovaPessoaFisica();
        Integer id = 56;
        ResponseEntity<PessoaFisica> responseEntity = api.pessoafisicaIdPut(body, id);
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

    @Test
    public void pessoafisicaPostTest() throws Exception {
        PessoaFisica body = new PessoaFisica();
        ResponseEntity<NovaPessoaFisica> responseEntity = api.pessoafisicaPost(body);
        assertEquals(HttpStatus.NOT_IMPLEMENTED, responseEntity.getStatusCode());
    }

}
