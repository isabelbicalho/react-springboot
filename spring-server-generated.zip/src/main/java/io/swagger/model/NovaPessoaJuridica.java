package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * NovaPessoaJuridica
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-07-05T16:44:52.301Z[GMT]")
public class NovaPessoaJuridica   {
  @JsonProperty("companyName")
  private String companyName = null;

  @JsonProperty("cnpj")
  private Integer cnpj = null;

  @JsonProperty("postalCode")
  private Integer postalCode = null;

  @JsonProperty("phones")
  @Valid
  private List<String> phones = new ArrayList<String>();

  @JsonProperty("email")
  private String email = null;

  /**
   * Gets or Sets stage
   */
  public enum StageEnum {
    ACTIVE("active"),
    
    INACTIVE("inactive");

    private String value;

    StageEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StageEnum fromValue(String text) {
      for (StageEnum b : StageEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("stage")
  private StageEnum stage = null;

  public NovaPessoaJuridica companyName(String companyName) {
    this.companyName = companyName;
    return this;
  }

  /**
   * Get companyName
   * @return companyName
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  public NovaPessoaJuridica cnpj(Integer cnpj) {
    this.cnpj = cnpj;
    return this;
  }

  /**
   * Get cnpj
   * @return cnpj
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  public Integer getCnpj() {
    return cnpj;
  }

  public void setCnpj(Integer cnpj) {
    this.cnpj = cnpj;
  }

  public NovaPessoaJuridica postalCode(Integer postalCode) {
    this.postalCode = postalCode;
    return this;
  }

  /**
   * Get postalCode
   * @return postalCode
  **/
  @ApiModelProperty(value = "")

  public Integer getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(Integer postalCode) {
    this.postalCode = postalCode;
  }

  public NovaPessoaJuridica phones(List<String> phones) {
    this.phones = phones;
    return this;
  }

  public NovaPessoaJuridica addPhonesItem(String phonesItem) {
    this.phones.add(phonesItem);
    return this;
  }

  /**
   * Get phones
   * @return phones
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  public List<String> getPhones() {
    return phones;
  }

  public void setPhones(List<String> phones) {
    this.phones = phones;
  }

  public NovaPessoaJuridica email(String email) {
    this.email = email;
    return this;
  }

  /**
   * Get email
   * @return email
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public NovaPessoaJuridica stage(StageEnum stage) {
    this.stage = stage;
    return this;
  }

  /**
   * Get stage
   * @return stage
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  public StageEnum getStage() {
    return stage;
  }

  public void setStage(StageEnum stage) {
    this.stage = stage;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    NovaPessoaJuridica novaPessoaJuridica = (NovaPessoaJuridica) o;
    return Objects.equals(this.companyName, novaPessoaJuridica.companyName) &&
        Objects.equals(this.cnpj, novaPessoaJuridica.cnpj) &&
        Objects.equals(this.postalCode, novaPessoaJuridica.postalCode) &&
        Objects.equals(this.phones, novaPessoaJuridica.phones) &&
        Objects.equals(this.email, novaPessoaJuridica.email) &&
        Objects.equals(this.stage, novaPessoaJuridica.stage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(companyName, cnpj, postalCode, phones, email, stage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NovaPessoaJuridica {\n");
    
    sb.append("    companyName: ").append(toIndentedString(companyName)).append("\n");
    sb.append("    cnpj: ").append(toIndentedString(cnpj)).append("\n");
    sb.append("    postalCode: ").append(toIndentedString(postalCode)).append("\n");
    sb.append("    phones: ").append(toIndentedString(phones)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    stage: ").append(toIndentedString(stage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
