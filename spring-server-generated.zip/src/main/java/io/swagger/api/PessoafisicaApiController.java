package io.swagger.api;

import io.swagger.model.NovaPessoaFisica;
import io.swagger.model.PessoaFisica;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2019-07-05T16:44:52.301Z[GMT]")
@Controller
public class PessoafisicaApiController implements PessoafisicaApi {

    private static final Logger log = LoggerFactory.getLogger(PessoafisicaApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public PessoafisicaApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<List<PessoaFisica>> pessoafisicaGet() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<PessoaFisica>>(objectMapper.readValue("[ "", "" ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<PessoaFisica>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<PessoaFisica>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Void> pessoafisicaIdDelete(@ApiParam(value = "Id de pessoa física",required=true) @PathVariable("id") Integer id) {
        String accept = request.getHeader("Accept");
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<PessoaFisica>> pessoafisicaIdGet(@ApiParam(value = "Id de pessoa física",required=true) @PathVariable("id") Integer id) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<List<PessoaFisica>>(objectMapper.readValue("[ "", "" ]", List.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<PessoaFisica>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<PessoaFisica>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<PessoaFisica> pessoafisicaIdPut(@ApiParam(value = "" ,required=true )  @Valid @RequestBody NovaPessoaFisica body,@ApiParam(value = "Id de pessoa física",required=true) @PathVariable("id") Integer id) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<PessoaFisica>(objectMapper.readValue("""", PessoaFisica.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<PessoaFisica>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<PessoaFisica>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<NovaPessoaFisica> pessoafisicaPost(@ApiParam(value = "" ,required=true )  @Valid @RequestBody PessoaFisica body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<NovaPessoaFisica>(objectMapper.readValue("{
  "stage" : "active",
  "postalCode" : 6,
  "name" : "name",
  "cpf" : 0,
  "phones" : [ "phones", "phones" ],
  "email" : "email"
}", NovaPessoaFisica.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<NovaPessoaFisica>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<NovaPessoaFisica>(HttpStatus.NOT_IMPLEMENTED);
    }

}
